
-- --------------------------------------------------------

--
-- Structure de la table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `item_ID` int(11) NOT NULL AUTO_INCREMENT,
  `item_Nom` varchar(255) NOT NULL,
  `item_Description` varchar(2000) NOT NULL,
  `item_Photo` varchar(255) NOT NULL,
  `item_Categorie` varchar(255) NOT NULL,
  `item_IDVendeur` int(200) NOT NULL,
  `item_TypeVente` int(3) NOT NULL,
  `item_Statut` tinyint(1) DEFAULT NULL,
  `item_IDAcheteur` int(200) NOT NULL,
  `item_Prix` double NOT NULL,
  `item_Tentative` int(6) NOT NULL,
  `item_Offre` double NOT NULL,
  `item_Temps` time NOT NULL,
  PRIMARY KEY (`item_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `item`
--

INSERT INTO `item` (`item_ID`, `item_Nom`, `item_Description`, `item_Photo`, `item_Categorie`, `item_IDVendeur`, `item_TypeVente`, `item_Statut`, `item_IDAcheteur`, `item_Prix`, `item_Tentative`, `item_Offre`, `item_Temps`) VALUES
(1, 'Piece', 'UN vieille piece fonctionnelle', 'piece.jpg', '1', 1, 4, NULL, 0, 1000, 0, 0, '00:00:00'),
(3, 'BestWaifu', 'Une relique baignée de lumiere', 'BestWaifu.jpg', '1', 0, 1, NULL, 0, 100000, 0, 0, '00:00:00');
