
-- --------------------------------------------------------

--
-- Structure de la table `acheteur`
--

DROP TABLE IF EXISTS `acheteur`;
CREATE TABLE IF NOT EXISTS `acheteur` (
  `acheteur_ID` int(200) NOT NULL AUTO_INCREMENT,
  `acheteur_Nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `acheteur_Prenom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `acheteur_Adresse1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `acheteur_CodePost` int(11) NOT NULL,
  `acheteur_Pays` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `acheteur_Tel` varchar(11) NOT NULL,
  `acheteur_Adresse2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `acheteur_Ville` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `acheteur_mdp` varchar(255) NOT NULL,
  `acheteur_Mail` varchar(255) NOT NULL,
  PRIMARY KEY (`acheteur_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `acheteur`
--

INSERT INTO `acheteur` (`acheteur_ID`, `acheteur_Nom`, `acheteur_Prenom`, `acheteur_Adresse1`, `acheteur_CodePost`, `acheteur_Pays`, `acheteur_Tel`, `acheteur_Adresse2`, `acheteur_Ville`, `acheteur_mdp`, `acheteur_Mail`) VALUES
(6, 'Tes', 'Te', '41 Rue L\"é', 69420, 'Poitou', '0178451232', '5e Arr\"é&', 'Paname', 'aeazeaz', 'foudu3@fromage.com'),
(5, 'Vic', 'Tor', 'eza', 69420, 'Panama', '0145263312', 'eza', 'Paname', 'fromage', 'foudu3@fromage.com');
