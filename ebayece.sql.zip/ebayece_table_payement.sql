
-- --------------------------------------------------------

--
-- Structure de la table `payement`
--

DROP TABLE IF EXISTS `payement`;
CREATE TABLE IF NOT EXISTS `payement` (
  `payement_ID` int(200) NOT NULL AUTO_INCREMENT,
  `payement_Type` int(4) NOT NULL,
  `payement_Date` date NOT NULL,
  `payement_Code` int(3) NOT NULL,
  `payement_Numero` int(12) NOT NULL,
  `payement_NomTitulaire` int(11) NOT NULL,
  `payement_Provision` int(11) NOT NULL,
  PRIMARY KEY (`payement_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
