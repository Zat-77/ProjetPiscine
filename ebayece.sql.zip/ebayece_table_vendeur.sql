
-- --------------------------------------------------------

--
-- Structure de la table `vendeur`
--

DROP TABLE IF EXISTS `vendeur`;
CREATE TABLE IF NOT EXISTS `vendeur` (
  `vendeur_ID` int(200) NOT NULL AUTO_INCREMENT,
  `vendeur_Nom` varchar(255) NOT NULL,
  `vendeur_Pseudo` varchar(255) NOT NULL,
  `vendeur_Mail` varchar(255) NOT NULL,
  `vendeur_Mdp` varchar(255) NOT NULL,
  `vendeur_Photo` varchar(255) NOT NULL,
  `vendeur_Fond` varchar(255) NOT NULL,
  `vendeur_Admin` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`vendeur_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `vendeur`
--

INSERT INTO `vendeur` (`vendeur_ID`, `vendeur_Nom`, `vendeur_Pseudo`, `vendeur_Mail`, `vendeur_Mdp`, `vendeur_Photo`, `vendeur_Fond`, `vendeur_Admin`) VALUES
(1, 'rez', 're', 'rez', 'ezaa', 'test.jpg', 'bleu', NULL);
