
-- --------------------------------------------------------

--
-- Structure de la table `negociation`
--

DROP TABLE IF EXISTS `negociation`;
CREATE TABLE IF NOT EXISTS `negociation` (
  `nego_ID` int(11) NOT NULL AUTO_INCREMENT,
  `nego_IDItem` int(11) NOT NULL,
  `nego_IDAcheteur` int(11) NOT NULL,
  `nego_Tentative` int(11) NOT NULL,
  `nego_Offre` int(11) NOT NULL,
  `nego_ContreOffre` int(11) NOT NULL,
  PRIMARY KEY (`nego_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
