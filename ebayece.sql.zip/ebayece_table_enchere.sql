
-- --------------------------------------------------------

--
-- Structure de la table `enchere`
--

DROP TABLE IF EXISTS `enchere`;
CREATE TABLE IF NOT EXISTS `enchere` (
  `enchere_ID` int(11) NOT NULL AUTO_INCREMENT,
  `enchere_IDVendeur` int(11) NOT NULL,
  `enchere_IDAcheteur` int(11) NOT NULL,
  `enchere_PrixMax` int(11) NOT NULL,
  PRIMARY KEY (`enchere_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
