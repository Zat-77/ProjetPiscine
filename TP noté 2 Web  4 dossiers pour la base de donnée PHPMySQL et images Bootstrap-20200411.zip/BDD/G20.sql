-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 09, 2020 at 09:00 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tpnote22020`
--

-- --------------------------------------------------------

--
-- Table structure for table `g20`
--

DROP TABLE IF EXISTS `g20`;
CREATE TABLE IF NOT EXISTS `g20` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Membre` varchar(255) NOT NULL,
  `Region` varchar(255) NOT NULL,
  `Population` int(11) NOT NULL,
  `PIBParTete` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g20`
--

INSERT INTO `g20` (`ID`, `Membre`, `Region`, `Population`, `PIBParTete`) VALUES
(1, 'Afrique du Sud', 'Afrique', 56717156, 6160),
(2, 'Canada', 'Amerique du Nord', 36708083, 45032),
(3, 'Mexique', 'Amerique du Nord', 129163276, 8902),
(4, 'Etats-Unis', 'Amerique du Nord', 325719178, 59531),
(5, 'Argentine', 'Amerique du Sud', 44271041, 14401),
(6, 'Bresil', 'Amerique du Sud', 209288278, 9821),
(7, 'Chine', 'Asie', 1386000000, 8826),
(8, 'Japon', 'Asie', 126785797, 38428),
(9, 'Coree du Sud', 'Asie', 51466201, 29742),
(10, 'Inde', 'Asie', 1339000000, 1939),
(11, 'Indonesie', 'Asie', 263991279, 3846),
(12, 'Arabie saoudite', 'Asie', 32938213, 20760),
(13, 'Turquie', 'Asie', 80740020, 10540),
(14, 'Union europeenne', 'Europe', 512461290, 33715),
(15, 'France', 'Europe', 67118648, 38476),
(16, 'Allemagne', 'Europe', 82695000, 44470),
(17, 'Italie', 'Europe', 60551416, 31952),
(18, 'Royaume-Uni', 'Europe', 66022273, 39720),
(19, 'Russie', 'Europe', 144495044, 10743);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
